Steps to run the performance test on Jmeter:
1. Donwload jmeter from here -- > https://downloads.apache.org/
2. Open the file.jmx on jmeter.
3. Run the script using the green button on the top header of jmeter view.
4. You can control the concurrent users using an element on the left hand pane called "Thread Group".
5. Inspect the file.xml to see the failed request and analyze the output.